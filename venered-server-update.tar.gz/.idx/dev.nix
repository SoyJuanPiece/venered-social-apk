{ pkgs, ... }: {
  # The nixpkgs channel to use.
  channel = "stable-23.11"; # or "unstable"

  # A list of packages to have available in your environment.
  packages = [
    pkgs.nodejs_20
  ];

  # A set of environment variables to be available in your development environment.
  env = {
    API_KEY = "your-secret-key";
  };

  # VS Code extensions to install in your workspace.
  idx = {
    extensions = [
      "dbaeumer.vscode-eslint"
    ];
    workspace = {
      # Commands to run when your workspace is created.
      onCreate = {
        npm-install = "npm install";
      };
      # Commands to run when your workspace is started or restarted.
      onStart = {
        dev-server = "npm run dev";
      };
    };
    previews = {
      enable = true;
      previews = {
        web = {
          command = ["npm" "run" "dev" "--" "--port" "$PORT"];
          manager = "web";
        };
      };
    };
  };
}
