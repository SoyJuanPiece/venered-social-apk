require('dotenv').config();
const express = require('express');
const multer = require('multer');
const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');

// --- Constantes y Configuración ---
const DB_FILE = './gallery.json';

// Asegurar que el archivo de base de datos existe
if (!fs.existsSync(DB_FILE)) {
  fs.writeFileSync(DB_FILE, '[]');
}

const token = process.env.TELEGRAM_BOT_TOKEN;
const chatId = process.env.TELEGRAM_CHAT_ID;
const bot = new TelegramBot(token);

const app = express();
const port = process.env.PORT || 3000;

// --- Middleware ---
app.use(express.static('public'));
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
  next();
});

const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

// --- Funciones Auxiliares ---

// Función para obtener una URL fresca a partir de un file_id
async function getFileUrl(fileId) {
  try {
    const file = await bot.getFile(fileId);
    return `https://api.telegram.org/file/bot${token}/${file.file_path}`;
  } catch (error) {
    console.error(`Error obteniendo URL para file_id ${fileId}:`, error.response ? error.response.body : error.message);
    return null;
  }
}

// --- Rutas de la API ---

// GET /api/gallery: Ahora genera URLs frescas en cada carga
app.get('/api/gallery', async (req, res) => {
  try {
    const galleryData = JSON.parse(fs.readFileSync(DB_FILE, 'utf8') || '[]');
    
    // Usamos Promise.all para pedir todas las URLs en paralelo
    const galleryWithFreshUrls = await Promise.all(
      galleryData.map(async (item) => {
        const freshUrl = await getFileUrl(item.file_id);
        return {
          ...item,
          url: freshUrl, // Sobrescribimos la URL (que podría ser nula o expirada)
        };
      })
    );

    // Filtramos los items que no pudieron obtener una URL fresca
    const validItems = galleryWithFreshUrls.filter(item => item.url !== null);
    
    res.status(200).json(validItems);

  } catch (err) {
    console.error('Error en GET /api/gallery:', err);
    res.status(500).json({ message: 'Error interno del servidor' });
  }
});

// POST /upload: Guarda el file_id y devuelve la URL inicial
app.post('/upload', upload.single('media'), async (req, res) => {
  console.log('Recibida petición de subida...');
  if (!req.file) {
    console.log('Error: No hay archivo en la petición.');
    return res.status(400).json({ message: 'No se ha subido ningún archivo.' });
  }

  const { buffer, mimetype, originalname } = req.file;
  console.log(`Subiendo archivo: ${originalname} (${mimetype}) - ${buffer.length} bytes`);
  
  const fileType = mimetype.startsWith('image') ? 'photo' : 
                   (mimetype.startsWith('audio') ? 'audio' : 
                   (mimetype.startsWith('video') ? 'video' : 'document'));

  try {
    let sentMessage;
    const fileOptions = { filename: originalname, contentType: mimetype };

    if (fileType === 'photo') {
      sentMessage = await bot.sendPhoto(chatId, buffer, {}, fileOptions);
    } else if (fileType === 'audio') {
      sentMessage = await bot.sendAudio(chatId, buffer, {}, fileOptions);
    } else if (fileType === 'video') {
      sentMessage = await bot.sendVideo(chatId, buffer, {}, fileOptions);
    } else {
      console.log('Error: Formato no soportado.');
      return res.status(400).json({ message: 'Formato de archivo no soportado.' });
    }

    console.log('Archivo enviado a Telegram con éxito.');

    // ¡IMPORTANTE! Obtenemos el file_id correcto según el tipo
    let file_id;
    if (sentMessage.photo) file_id = sentMessage.photo.pop().file_id;
    else if (sentMessage.audio) file_id = sentMessage.audio.file_id;
    else if (sentMessage.video) file_id = sentMessage.video.file_id;
    else if (sentMessage.document) file_id = sentMessage.document.file_id;
    
    // Generamos la URL inicial para la respuesta inmediata
    const initialUrl = await getFileUrl(file_id);
    if (!initialUrl) throw new Error('No se pudo obtener la URL inicial del archivo.');

    const galleryData = JSON.parse(fs.readFileSync(DB_FILE, 'utf8') || '[]');
    const newEntry = {
      id: sentMessage.message_id,
      file_id, 
      filename: originalname,
      type: fileType,
      date: sentMessage.date,
      isStory: req.body.isStory === 'true', // Marcamos si es una historia
      expiresAt: req.body.isStory === 'true' ? (sentMessage.date + 86400) : null // 24h después
    };
    
    galleryData.unshift(newEntry);
    fs.writeFileSync(DB_FILE, JSON.stringify(galleryData, null, 2));
    
    console.log(`Registro guardado en base de datos: ${file_id}`);
    
    // Devolvemos el objeto con la URL inicial para que la UI lo muestre al momento
    res.status(200).json({ ...newEntry, url: initialUrl });

  } catch (error) {
    console.error('Error en el proceso de subida:', error);
    res.status(500).json({ message: 'Error en el servidor al subir el archivo.' });
  }
});

// GET /api/url/:fileId: Obtiene una URL fresca para un archivo específico
app.get('/api/url/:fileId', async (req, res) => {
  try {
    const { fileId } = req.params;
    const freshUrl = await getFileUrl(fileId);
    if (!freshUrl) return res.status(404).json({ message: 'Archivo no encontrado en Telegram' });
    res.status(200).json({ url: freshUrl });
  } catch (err) {
    res.status(500).json({ message: 'Error obteniendo URL' });
  }
});

// --- Iniciar Servidor ---
app.listen(port, () => console.log(`Servidor en puerto ${port}. Sistema de URLs persistentes activado.`));
